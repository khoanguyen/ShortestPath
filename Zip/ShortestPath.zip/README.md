ShortestPath
============

# Requirement

* .NET 4.0
* NUnit 2.6.x
* Visual C# 2010 Express

# Description

This is implementation of Finding Shortest Path in Road System using Dikjstra algorithm


Download the zip package of the source code from Zip folder

# Running UnitTest

Run [NUnit folder]/bin/nunit-x86.exe
Open project file ShortestPath.nunit in the solution dir

# Running the WPF Application

Open Project in Visual C# 2010 -> Build project -> press F5

Use "Browse Files..." button to select files or "Load files from working directory" to proceed all files in the working directory